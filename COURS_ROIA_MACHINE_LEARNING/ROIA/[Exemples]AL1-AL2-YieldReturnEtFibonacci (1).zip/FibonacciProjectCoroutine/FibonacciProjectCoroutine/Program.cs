﻿///////////////////////////////////////////////////////////////////////
////////  PROJET            : Fibonacci avec des coroutines.  /////////
////////  AUTHOR            : Nicolas Vidal                   /////////
////////  LAST MODIFICATION : 2013-11-28                      /////////
////////  RESUME            : Ce projet a pour but d'illustrer/////////
////////                      l'utilisation du mot clef       /////////
////////                      yield return                    /////////
///////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FibonacciProjectCoroutine
{
    /// <summary>
    /// Classe principale
    /// </summary>
    class Program
    {
        /// <summary>
        /// La version 'coroutine' de la suite de Fibonacci
        /// Calcule et renvoie successivement les valeurs 
        /// de cette dernière.
        /// On affiche la valeur que l'on s'apprète à émettre
        /// avant chaque yield return pour bien comprendre
        /// l'ordre d'appel des instructions lorsque l'on
        /// exéute la coroutine petit à petit.
        /// </summary>
        /// <returns>
        /// Renvoie une collection énumérable pouvant
        /// exposer un énumérateur (iterator)
        /// </returns>
        static IEnumerable<int> FiboYieldReturn()
        {
            #region Initialisation de la suite de fibonnacci
            Console.WriteLine("AVANT 0");
            yield return 0;
            Console.WriteLine("AVANT 1");
            yield return 1;
            Console.WriteLine("AVANT 2");
            yield return 2;

            var num1 = 1;
            var num2 = 2;
            #endregion

            /// A partir du 3eme élément on renvoie le résultat
            /// de la somme des 2 éléments précédents.
            while (true)
            {
                num2 = num1 + num2;
                num1 = num2 - num1;
                Console.WriteLine("AVANT " + num2);
                yield return num2;
            }
        }

        /// <summary>
        /// La version 'classique' de la suite de Fibonacci
        /// Calcule et renvoie la valeur du nième élément
        /// de cette dernière.
        /// </summary>
        /// <param name="n">
        /// La position de l'élément de la suite de Fibonacci
        /// que l'on souhaite calculer
        /// </param>
        /// <returns>
        /// Renvoie la valeur du nième élément de la suite de
        /// Fibonacci.
        /// </returns>
        static int FiboClassic(int n)
        {
            #region Initialisation de la suite
            if (n == 0)
                return 0;

            if (n == 1)
                return 1;

            if (n == 2)
                return 2;

            var num1 = 1;
            var num2 = 2;
            var it = 2;

            #endregion

            /// A partir du 3eme élément on calcule le résultat
            /// de la somme des 2 éléments précédents, et ce jusqu'au
            /// nième.
            while (it < n)
            {
                num2 = num1 + num2;
                num1 = num2 - num1;
                it++;
            }
            return num2;
        }

        /// <summary>
        /// Implémentation personnelle du 'foreach' proposé en C#
        /// </summary>
        /// <typeparam name="T">Le type d'élément contenu dans la collection</typeparam>
        /// <param name="collec">La collection d'élément qui expose un énumérateur (iterator)</param>
        /// <param name="func">La fonction à exécuter sur chaque élément de la liste</param>
        static void MyForeach<T>(IEnumerable<T> collec, Action<T> func)
        {
            /// Récupération de l'itérator
            var iterator = collec.GetEnumerator();

            /// Tout pendant qu'il reste des éléments à récupérer (ou construire à la volée)
            while (iterator.MoveNext())
            {
                /// Exécute la méthode passée en paramètre sur l'élément courant
                func(iterator.Current);
            }
        }

        /// <summary>
        /// Point d'entrée de notre programme
        /// </summary>
        /// <param name="args">-</param>
        static void Main(string[] args)
        {
            /// Affichage des 10 premiers éléments de la suite de Fibonacci
            /// de manière classique
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(FiboClassic(i));
            }

            /// Pour séparer l'affichage de nos tests
            Console.WriteLine("----------------------------------------------");

            /// Récupération des 10 premiers éléments de la suite de Fibonacci
            /// en utilisant une coroutine
            foreach (var num in FiboYieldReturn().Take(10))
            {
                Console.WriteLine(num);
            }

            /// Pour séparer l'affichage de nos tests
            Console.WriteLine("----------------------------------------------");

            /// Exemple de chaîne d'opération que l'on peut faire subir à une collection 'infinie'
            /// sans pour construire cette collection 'infinie' (ce ne serait pas possible de stocker
            /// l'intégralité de la suite de Fibonacci en mémoire ^^)
            /// Exemple également d'utilisation de méthode anonymes (lambdas) et de type anonyme (élément
            /// construit dans la lambda du Select)
            var tab2 = FiboYieldReturn()
                .Where((elt) => elt % 15 == 3)
                .Take(3)
                .Select(elt2 =>
                    new
                    {
                        Origin = elt2,
                        Fois2 = elt2 * 2
                    }
                    );

            /// Affichage des éléments construits 'à la volée' de notre chaine traitements
            foreach (var num in tab2)
            {
                Console.WriteLine(num.Origin + "    " + num.Fois2);
            }

            /// Pour empêcher Visual Studio de fermer la console à la fin de notre programme
            Console.ReadLine();
        }
    }
}
